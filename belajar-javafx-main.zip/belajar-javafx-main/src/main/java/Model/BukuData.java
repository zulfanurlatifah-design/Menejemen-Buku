package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class BukuData {
    private final ObservableList<Buku> items = FXCollections.observableArrayList();

    public ObservableList<Buku> getItems() {
        return items;
    }

    public void add(Buku buku) {
        items.add(buku);
    }

    public void remove(Buku buku) {
        items.remove(buku);
    }
}


