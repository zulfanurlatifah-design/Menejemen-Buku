package Model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Buku {
    private final StringProperty namaBuku = new SimpleStringProperty(this, "namaBuku", "");
    private final StringProperty deskripsi = new SimpleStringProperty(this, "deskripsi", "");
    private final StringProperty namaPenulis = new SimpleStringProperty(this, "namaPenulis", "");
    private final IntegerProperty tahun = new SimpleIntegerProperty(this, "tahun", 0);

    public Buku() {}

    public Buku(String namaBuku, String deskripsi, String namaPenulis, int tahun) {
        setNamaBuku(namaBuku);
        setDeskripsi(deskripsi);
        setNamaPenulis(namaPenulis);
        setTahun(tahun);
    }

    public String getNamaBuku() {
        return namaBuku.get();
    }

    public void setNamaBuku(String value) {
        namaBuku.set(value);
    }

    public StringProperty namaBukuProperty() {
        return namaBuku;
    }

    public String getDeskripsi() {
        return deskripsi.get();
    }

    public void setDeskripsi(String value) {
        deskripsi.set(value);
    }

    public StringProperty deskripsiProperty() {
        return deskripsi;
    }

    public String getNamaPenulis() {
        return namaPenulis.get();
    }

    public void setNamaPenulis(String value) {
        namaPenulis.set(value);
    }

    public StringProperty namaPenulisProperty() {
        return namaPenulis;
    }

    public int getTahun() {
        return tahun.get();
    }

    public void setTahun(int value) {
        tahun.set(value);
    }

    public IntegerProperty tahunProperty() {
        return tahun;
    }
}


