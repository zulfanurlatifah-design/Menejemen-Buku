package Controller;

import Model.Buku;
import Model.BukuData;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class BukuController implements Initializable {
    @FXML
    private TextField namaBukuInput;
    @FXML
    private TextField deskripsiInput;
    @FXML
    private TextField namaPenulisInput;
    @FXML
    private TextField tahunInput;
    @FXML
    private TableView<Buku> data;
    @FXML
    private TableColumn<Buku, String> colNamaBuku;
    @FXML
    private TableColumn<Buku, String> colDeskripsi;
    @FXML
    private TableColumn<Buku, String> colNamaPenulis;
    @FXML
    private TableColumn<Buku, Integer> colTahun;

    private final BukuData bukuData = new BukuData();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colNamaBuku.setCellValueFactory(new PropertyValueFactory<>("namaBuku"));
        colDeskripsi.setCellValueFactory(new PropertyValueFactory<>("deskripsi"));
        colNamaPenulis.setCellValueFactory(new PropertyValueFactory<>("namaPenulis"));
        colTahun.setCellValueFactory(new PropertyValueFactory<>("tahun"));

        data.setItems(bukuData.getItems());
    }

    @FXML
    private void buttonAdd(ActionEvent event) {
        String namaBuku = safe(namaBukuInput.getText());
        String deskripsi = safe(deskripsiInput.getText());
        String namaPenulis = safe(namaPenulisInput.getText());
        String tahunText = safe(tahunInput.getText());

        if (namaBuku.isEmpty() || namaPenulis.isEmpty() || tahunText.isEmpty()) {
            showError("Input tidak lengkap", "Nama Buku, Nama Penulis, dan Tahun wajib diisi.");
            return;
        }

        Integer tahunParsed = parseTahun(tahunText);
        if (tahunParsed == null) {
            showError("Format tahun salah", "Masukkan angka tahun yang valid.");
            return;
        }

        Buku buku = new Buku(namaBuku, deskripsi, namaPenulis, tahunParsed);
        bukuData.add(buku);
        clearInputs();
    }

    @FXML
    private void buttonEdit(ActionEvent event) {
        Buku selected = data.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Tidak ada pilihan", "Pilih data yang akan diedit.");
            return;
        }

        String namaBuku = safe(namaBukuInput.getText());
        String deskripsi = safe(deskripsiInput.getText());
        String namaPenulis = safe(namaPenulisInput.getText());
        String tahunText = safe(tahunInput.getText());

        if (!namaBuku.isEmpty()) {
            selected.setNamaBuku(namaBuku);
        }
        if (!deskripsi.isEmpty()) {
            selected.setDeskripsi(deskripsi);
        }
        if (!namaPenulis.isEmpty()) {
            selected.setNamaPenulis(namaPenulis);
        }
        if (!tahunText.isEmpty()) {
            Integer tahunParsed = parseTahun(tahunText);
            if (tahunParsed == null) {
                showError("Format tahun salah", "Masukkan angka tahun yang valid.");
                return;
            }
            selected.setTahun(tahunParsed);
        }

        data.refresh();
        clearInputs();
    }

    @FXML
    private void buttonDelete(ActionEvent event) {
        ObservableList<Buku> items = data.getItems();
        Buku selected = data.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Tidak ada pilihan", "Pilih data yang akan dihapus.");
            return;
        }
        items.remove(selected);
        clearInputs();
    }

    private void clearInputs() {
        namaBukuInput.clear();
        deskripsiInput.clear();
        namaPenulisInput.clear();
        tahunInput.clear();
    }

    private Integer parseTahun(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}


